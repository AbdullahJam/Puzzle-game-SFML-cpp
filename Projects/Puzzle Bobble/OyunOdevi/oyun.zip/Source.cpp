#include "Oyun.h"


int main()
{
    Oyun oyun;
    oyun.guncel();
    return 0;
}